<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css"/>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>All Users</h2>
                <h6>Navigate to: 
                    <a class="btn btn-primary" href="<?php echo e(route('users.add')); ?>">Add User</a>
                    <a class="btn btn-primary" href="<?php echo e(route('tasks.all')); ?>">All Tasks</a>
                    <a class="btn btn-primary" href="<?php echo e(route('tasks.add')); ?>">Add Task</a>
                </h6>
            </div>
            <div class="card-body">
                <table id="usertable">
                    <thead>
                        <tr>
                            <td>Name</td>
                            <td>Email</td>
                            <td>Mobile</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->mobile); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <button onclick="exprt()" class="btn btn-primary">Export to XLSX</button>
            </div>
        </div>
    </div>
    <script>
        let table = new DataTable('#usertable');
    </script>
    <script>
        function exprt(){
            $("#usertable").table2excel({
                filename: "Users.xls"
            });
        }
    </script>
</body>
</html><?php /**PATH D:\task\taskmanager\resources\views/users/all.blade.php ENDPATH**/ ?>